## Description

The complex example show:
* How to create new PKCS#10;
* How to load and parse binary encoded PKCS#10a;
* How to use validate PKCS#10;
