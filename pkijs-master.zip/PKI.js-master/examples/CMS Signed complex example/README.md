## Description

The complex example show:
* How to create new CMS Signed Data;
* How to load and parse binary encoded CMS Signed Data;
* How to use validate CMS Signed Data (with usage of "certificate validation chain engine");

In order to perform correct certificate validation you will need the "CA bundle" (see "Examples" directory for PKIjs project).