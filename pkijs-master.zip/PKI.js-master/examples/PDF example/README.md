## Description

The example is shown signed PDF signature validation. PDF parser came from [PDF.js](https://github.com/mozilla/pdf.js) project.

In order to perform correct certificate validation you will need the "CA bundle" (see "Examples" directory for PKIjs project).