## Description

The complex example show:
* How to create new TSP response;
* How to load and parse binary encoded TSP response;
* How to use validate TSP response (with usage of "certificate validation chain engine");

In order to perform correct certificate validation you will need the "CA bundle" (see "Examples" directory for PKIjs project).