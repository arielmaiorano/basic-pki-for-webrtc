## Description

This is a "CA bundle" - PEM file with all current CA certificates of well-known authorities. Actual version of the file can be found by [the link](http://curl.haxx.se/ca/cacert.pem).