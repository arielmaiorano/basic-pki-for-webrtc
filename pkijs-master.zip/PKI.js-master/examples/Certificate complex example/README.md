## Description

The complex example show:
* How to create new X.509 certificate;
* How to load and parse binary encoded X.509 certificates;
* How to use "certificate validation chain engine" for proper X.509 certificate validation;

In order to perform correct certificate validation you will need the "CA bundle" (see "Examples" directory for PKIjs project).