## Description

The examples is shown S/MIME signature validation. The MIME parser came from [Whiteout Networks](https://github.com/whiteout-io) GitHub repositories.

In order to perform correct certificate validation you will need the "CA bundle" (see "Examples" directory for PKIjs project).