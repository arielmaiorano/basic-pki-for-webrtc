## Description

The complex example show:
* How to create new X.509 certificate revocation list (CRL);
* How to load and parse binary encoded CRL;
* How to use verify CRL signature correctly;

