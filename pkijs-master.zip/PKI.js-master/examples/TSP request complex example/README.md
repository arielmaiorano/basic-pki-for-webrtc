## Description

The complex example show:
* How to create new TSP request;
* How to load and parse binary encoded TSP request;
